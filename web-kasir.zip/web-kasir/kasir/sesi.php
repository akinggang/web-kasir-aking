<?php 

if (empty($_SESSION['idkaskit']) AND empty($_SESSION['idkaskit'])) {
	header("location: ../");
}



 ?>